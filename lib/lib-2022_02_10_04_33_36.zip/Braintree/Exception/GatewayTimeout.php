<?php

namespace Braintree\Exception;

use Braintree\Exception;

/**
 * Raised when a gateway response timeout occurs.
 */
class GatewayTimeout extends Exception
{
}
